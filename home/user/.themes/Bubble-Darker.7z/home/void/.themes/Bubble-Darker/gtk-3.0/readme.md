# Credits
Gtk3 themes base on [Arc-Theme](https://github.com/horst3180/arc-theme) </br>
License : [GPLv3](https://choosealicense.com/licenses/gpl-3.0/)</br>

# Installation
Extract archive files in directory /.themes, /.local/share/themes or /usr/share/themes (as root)</b>
Have been test on : Debian Buster (10,11), Ubuntu (18.04, 20.04) LTS, Linux Mint (19,20)</br>

# Change themes
Gnome Desktop : Use Tweak Tool to change the themes, Gnome Tweak > Appeareance > Themes</br>
Cinnamon : Menu > Settings > Themes > Themes > Controls</br>
Xfce : Appearance > Style </b>
