# Credits
Cinnamon themes base on [Arc-themes](https://github.com/horst3180/arc-theme)
License [GPLv3](https://choosealicense.com/licenses/gpl-3.0/)</br>

# Installation
Test on Linux Mint 20.2 Cinnamon 5.0.7
Extract archive file On directory<i>/.themes or /usr/share/themes (as root),</i> </br>

## Change themes
Use themes settings to change the Cinnamon Themes.</br>
Linux Mint (Cinnamon): Menu > Settings > Themes > Themes > Desktop</br>
